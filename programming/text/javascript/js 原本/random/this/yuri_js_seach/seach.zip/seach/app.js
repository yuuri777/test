function seach2(){
    let text ="むかし、むかし、ある所におじいさんとおばあさんが住んでいました。おじいさんは山へしば刈りに、おばあさんは川へ洗濯に行きました。おばあさんが川で洗濯をしていると大きな桃が流れてきました。"

    const seach = document.getElementById("seach1");
    
    const se = "大きな";
    result= text.indexOf(se);
     //indexofとhtmlのidを繋げるためにはどうしたらいいか。
     //getbyidを使って。
     //seachと===で繋げると
    
     
    //document.getElementById("sample1").innerHTML=result
        
    const a=document.getElementById("sample1")
      if (result === -1){
        
        document.getElementById("sample1").innerHTML="結果：含まれていません。";
    }else{
        

        document.getElementById("sample1").innerHTML="結果：含まれています。";
    }
}
