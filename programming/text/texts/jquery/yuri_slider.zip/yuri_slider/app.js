$(function () {
    $(".slider").slick({
        autoplay: true,
        autoplayspeed: 1000,
        fade: true,
        swipe: false,
    });
});