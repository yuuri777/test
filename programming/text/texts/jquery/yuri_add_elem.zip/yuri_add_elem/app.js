$('ul').append('<li>項目</li>');
$('ul').append('<li>項目</li>');
$('ul').append('<li>項目</li>');