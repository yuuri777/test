
const test = name => {
    name=Math.floor(Math.random() * (3 +1 - 1)) + 1;
let result;
if(name === 1){
    result="大当たり";
}else if(name === 2){
    result="当たり";
}else {
    result="外れ";
}
    return result;
}
console.log(test());