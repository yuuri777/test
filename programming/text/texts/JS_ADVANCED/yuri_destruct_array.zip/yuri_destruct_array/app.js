const fruits = ["ブドウ","キウイ","パイナップル","イチゴ","バナナ"];

const [fruits1,fruits2,fruits3,fruits4,fruits5]=fruits;
const message=`1つ目:${fruits1}\n2つ目:${fruits2}\n3つ目:${fruits3}\n4つ目:${fruits4}\n5つ目:${fruits5}`;
console.log(message);