const test = name => {
    console.log("アロー関数が実行されました!")
}
test();