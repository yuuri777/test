const num = 100;

num >= 100 ? console.log("true") : console.log("false");