const arrayNum = [2,10,22,35,48,50];

const arrayresult = arrayNum.map(name => {
    const message = `${name** 2}`
return message;
})
console.log(arrayresult);