let name="根本裕理";
let age=24;
let hobby="自分のためになることをするのが"

let message=`私の名前は${name}です。年齢は${age}です。趣味は${hobby}です。よろしくお願いします。`

console.log(message);