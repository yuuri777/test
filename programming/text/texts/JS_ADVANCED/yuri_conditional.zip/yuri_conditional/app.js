const num = 1022;

num > 100 ? console.log("true") : console.log("false");